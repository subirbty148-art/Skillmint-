import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  where,
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { DEFAULT_COURSES, DEFAULT_PLANS, DEFAULT_SETTINGS } from '../lib/seedDefaults';
import {
  createOrEnsureUserProfile,
  seedInitialCatalogIfEmpty,
} from '../services/firestoreService';
import {
  Course,
  MembershipPlan,
  PlatformNotification,
  PlatformSettings,
  UserProfile,
} from '../types/domain';

const BOOTSTRAP_ADMIN_EMAIL = 'subirbty148@gmail.com';
const PENDING_REF_KEY = 'skillmint_pending_ref_code';

interface AuthContextValue {
  firebaseUser: FirebaseUser | null;
  profile: UserProfile | null;
  authReady: boolean;
  isAdmin: boolean;
  plans: MembershipPlan[];
  courses: Course[];
  settings: PlatformSettings;
  notifications: PlatformNotification[];
  pendingReferralCode: string;
  setPendingReferralCode: (code: string) => void;
  registerWithEmail: (params: {
    fullName: string;
    email: string;
    password: string;
    phone?: string;
    referralCode?: string;
  }) => Promise<void>;
  loginWithEmail: (email: string, password: string) => Promise<void>;
  loginWithGoogle: (referralCode?: string) => Promise<void>;
  sendResetEmail: (email: string) => Promise<void>;
  resendVerification: () => Promise<void>;
  refreshUserSession: () => Promise<boolean>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const [plans, setPlans] = useState<MembershipPlan[]>(
    DEFAULT_PLANS.map((p) => ({ ...p, updatedAt: null }))
  );
  const [courses, setCourses] = useState<Course[]>(
    DEFAULT_COURSES.map((c) => ({ ...c, createdAt: null, updatedAt: null }))
  );
  const [settings, setSettings] = useState<PlatformSettings>({
    ...DEFAULT_SETTINGS,
    updatedAt: null,
  });
  const [notifications, setNotifications] = useState<PlatformNotification[]>([]);

  const [pendingReferralCode, setPendingReferralCodeState] = useState<string>(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const urlRef = urlParams.get('ref');
      if (urlRef) {
        const clean = urlRef.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
        sessionStorage.setItem(PENDING_REF_KEY, clean);
        return clean;
      }
      return sessionStorage.getItem(PENDING_REF_KEY) || '';
    } catch {
      return '';
    }
  });

  const setPendingReferralCode = (code: string) => {
    const clean = code.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    setPendingReferralCodeState(clean);
    try {
      if (clean) sessionStorage.setItem(PENDING_REF_KEY, clean);
      else sessionStorage.removeItem(PENDING_REF_KEY);
    } catch {
      // ignore storage errors
    }
  };

  // Public listeners: Plans, Courses, Settings
  useEffect(() => {
    const unsubPlans = onSnapshot(
      query(collection(db, 'plans'), orderBy('tierOrder', 'asc')),
      (snap) => {
        if (!snap.empty) {
          setPlans(snap.docs.map((d) => d.data() as MembershipPlan));
        }
      },
      (err) => {
        console.warn('Plans listener warning:', err.message);
      }
    );

    const unsubCourses = onSnapshot(
      collection(db, 'courses'),
      (snap) => {
        if (!snap.empty) {
          setCourses(snap.docs.map((d) => d.data() as Course));
        }
      },
      (err) => {
        console.warn('Courses listener warning:', err.message);
      }
    );

    const unsubSettings = onSnapshot(
      doc(db, 'settings', 'platform'),
      (snap) => {
        if (snap.exists()) {
          setSettings(snap.data() as PlatformSettings);
        }
      },
      (err) => {
        console.warn('Settings listener warning:', err.message);
      }
    );

    return () => {
      unsubPlans();
      unsubCourses();
      unsubSettings();
    };
  }, []);

  // Auth state listener + Profile + Admin verification
  useEffect(() => {
    let unsubProfile: (() => void) | null = null;
    let unsubNotifsAll: (() => void) | null = null;
    let unsubNotifsUser: (() => void) | null = null;

    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      if (unsubProfile) {
        unsubProfile();
        unsubProfile = null;
      }
      if (unsubNotifsAll) {
        unsubNotifsAll();
        unsubNotifsAll = null;
      }
      if (unsubNotifsUser) {
        unsubNotifsUser();
        unsubNotifsUser = null;
      }

      setFirebaseUser(user);

      if (!user) {
        setProfile(null);
        setIsAdmin(false);
        setNotifications([]);
        setAuthReady(true);
        return;
      }

      try {
        // 1. Check Admin authorization via admins/{uid} + verified bootstrap email + server token check
        let adminAuthorized =
          user.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL && user.emailVerified === true;

        try {
          const adminDoc = await getDoc(doc(db, 'admins', user.uid));
          if (adminDoc.exists()) {
            adminAuthorized = true;
          }
        } catch {
          // Non-admin read denial on missing admin doc is expected; rely on bootstrap check
        }

        if (adminAuthorized) {
          try {
            const idToken = await user.getIdToken();
            await fetch('/api/auth/verify-session', {
              method: 'POST',
              headers: { Authorization: `Bearer ${idToken}` },
            });
          } catch {
            // non-blocking audit
          }
          // Seed initial catalog into Firestore if empty when admin signs in
          seedInitialCatalogIfEmpty().catch((e) => console.warn('Seed catalog:', e));
        }

        setIsAdmin(adminAuthorized);

        // 2. Ensure User Profile exists in Firestore
        const storedRef = (() => {
          try {
            return sessionStorage.getItem(PENDING_REF_KEY) || '';
          } catch {
            return '';
          }
        })();

        await createOrEnsureUserProfile({
          uid: user.uid,
          email: user.email || '',
          fullName: user.displayName || user.email?.split('@')[0] || 'SkillMint Member',
          referralCodeInput: storedRef,
        });

        // 3. Attach real-time profile snapshot
        unsubProfile = onSnapshot(
          doc(db, 'users', user.uid),
          (snap) => {
            if (snap.exists()) {
              setProfile(snap.data() as UserProfile);
            }
            setAuthReady(true);
          },
          (error) => {
            handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
          }
        );

        // 4. Attach notifications listeners (broadcast 'all' + user-specific)
        let broadcastList: PlatformNotification[] = [];
        let personalList: PlatformNotification[] = [];

        const mergeNotifs = () => {
          const merged = [...personalList, ...broadcastList].sort((a, b) => {
            const ta = a.createdAt?.toMillis?.() || 0;
            const tb = b.createdAt?.toMillis?.() || 0;
            return tb - ta;
          });
          setNotifications(merged.slice(0, 25));
        };

        unsubNotifsAll = onSnapshot(
          query(collection(db, 'notifications'), where('targetUserId', '==', 'all')),
          (snap) => {
            broadcastList = snap.docs.map((d) => d.data() as PlatformNotification);
            mergeNotifs();
          },
          (err) => console.warn('Broadcast notifications:', err.message)
        );

        unsubNotifsUser = onSnapshot(
          query(collection(db, 'notifications'), where('targetUserId', '==', user.uid)),
          (snap) => {
            personalList = snap.docs.map((d) => d.data() as PlatformNotification);
            mergeNotifs();
          },
          (err) => console.warn('Personal notifications:', err.message)
        );
      } catch (err) {
        console.error('Auth initialization error:', err);
        setAuthReady(true);
      }
    });

    return () => {
      unsubAuth();
      if (unsubProfile) unsubProfile();
      if (unsubNotifsAll) unsubNotifsAll();
      if (unsubNotifsUser) unsubNotifsUser();
    };
  }, []);

  const registerWithEmail = async (params: {
    fullName: string;
    email: string;
    password: string;
    phone?: string;
    referralCode?: string;
  }) => {
    if (params.referralCode) {
      setPendingReferralCode(params.referralCode);
    }
    const cred = await createUserWithEmailAndPassword(auth, params.email.trim(), params.password);
    await updateProfile(cred.user, { displayName: params.fullName.trim() });
    await createOrEnsureUserProfile({
      uid: cred.user.uid,
      email: params.email.trim(),
      fullName: params.fullName.trim(),
      phone: params.phone,
      referralCodeInput: params.referralCode || pendingReferralCode,
    });
    setPendingReferralCode('');
    try {
      await sendEmailVerification(cred.user);
    } catch {
      // non-blocking if rate limited
    }
  };

  const loginWithEmail = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email.trim(), password);
  };

  const loginWithGoogle = async (referralCode?: string) => {
    if (referralCode) {
      setPendingReferralCode(referralCode);
    }
    const cred = await signInWithPopup(auth, googleProvider);
    await createOrEnsureUserProfile({
      uid: cred.user.uid,
      email: cred.user.email || '',
      fullName: cred.user.displayName || cred.user.email?.split('@')[0] || 'SkillMint Member',
      referralCodeInput: referralCode || pendingReferralCode,
    });
    setPendingReferralCode('');
  };

  const sendResetEmail = async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
  };

  const resendVerification = async () => {
    if (!auth.currentUser) return;
    await sendEmailVerification(auth.currentUser);
  };

  const refreshUserSession = async (): Promise<boolean> => {
    if (!auth.currentUser) return false;
    await auth.currentUser.reload();
    await auth.currentUser.getIdToken(true);
    const updated = auth.currentUser;
    setFirebaseUser(updated);
    const adminAuthorized =
      updated.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL && updated.emailVerified === true;
    if (adminAuthorized) {
      setIsAdmin(true);
      await seedInitialCatalogIfEmpty();
    }
    return updated.emailVerified;
  };

  const logout = async () => {
    await signOut(auth);
  };

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        authReady,
        isAdmin,
        plans,
        courses,
        settings,
        notifications,
        pendingReferralCode,
        setPendingReferralCode,
        registerWithEmail,
        loginWithEmail,
        loginWithGoogle,
        sendResetEmail,
        resendVerification,
        refreshUserSession,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
